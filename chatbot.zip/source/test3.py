
print(ord(u'\xa0'))